import{default as t}from"../components/error.svelte-cf5a7749.js";export{t as component};
