import{default as t}from"../components/error.svelte-003ed5de.js";export{t as component};
