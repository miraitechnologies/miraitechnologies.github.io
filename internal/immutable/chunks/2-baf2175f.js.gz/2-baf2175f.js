import{default as t}from"../components/pages/_page.svelte-ef205776.js";export{t as component};
