import{_ as r}from"./_layout-bcc0c3e5.js";import{default as t}from"../components/pages/_layout.svelte-e3c8d308.js";export{t as component,r as shared};
