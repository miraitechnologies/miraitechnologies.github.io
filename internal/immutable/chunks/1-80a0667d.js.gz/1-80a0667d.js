import{default as t}from"../components/error.svelte-acfdaf08.js";export{t as component};
